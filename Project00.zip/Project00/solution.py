from typing import List, TypeVar



class Solution:
    T = TypeVar('T')

    def find_max(data: List[T]) -> T:
        """
        :param data: a list of like objects
        :return: maximal element of `data`
        """
