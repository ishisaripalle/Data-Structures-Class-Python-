import unittest
from random import shuffle
from solution import Solution

class Problem1TestCase(unittest.TestCase):
    def test_max(self):

        test1 = list(range(30))
        test2 = [char for char in 'abcdefghijk']
        test3 = ['cat', 'dog', 'G.O.A.T.']
        test4 = []
        shuffle(test1);
        shuffle(test2);
        shuffle(test3)

        # test numeric
        self.assertEqual(Solution.find_max(test1), 29)

        # test single character strings
        self.assertEqual(Solution.find_max(test2), 'k')

        # test strings
        self.assertEqual(Solution.find_max(test3), 'dog')

        # test empty
        self.assertIsNone(Solution.find_max(test4))


if __name__ == '__main__':
    unittest.main()