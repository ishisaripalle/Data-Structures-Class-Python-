"""
Adam Kasumovic and Joseph Pallipadan
Sorting Project - Starter
CSE 331 Spring 2023
"""

import random
import time
from typing import TypeVar, List, Callable, Dict
from dataclasses import dataclass

T = TypeVar("T")  # represents generic type


# do_comparison is an optional helper function but HIGHLY recommended!!!
def do_comparison(first: T, second: T, comparator: Callable[[T, T], bool], descending: bool) -> bool:
    """
    FILL OUT DOCSTRING
    """
    pass


def selection_sort(data: List[T], *, comparator: Callable[[T, T], bool] = lambda x, y: x < y,
                   descending: bool = False) -> None:
    """
    FILL OUT DOCSTRING
    """
    pass


def bubble_sort(data: List[T], *, comparator: Callable[[T, T], bool] = lambda x, y: x < y,
                descending: bool = False) -> None:
    """
    FILL OUT DOCSTRING
    """
    pass


def insertion_sort(data: List[T], *, comparator: Callable[[T, T], bool] = lambda x, y: x < y,
                   descending: bool = False) -> None:
    """
    FILL OUT DOCSTRING
    """
    pass


def hybrid_merge_sort(data: List[T], *, threshold: int = 12,
                      comparator: Callable[[T, T], bool] = lambda x, y: x < y, descending: bool = False) -> None:
    """
    FILL OUT DOCSTRING
    """
    pass


### DO NOT MODIFY ###
@dataclass
class Card:
    suit: str
    rank: str

    def value(self):
        if self.rank.isnumeric():
            return int(self.rank)
        else:
            return 10 if self.rank != "Ace" else 11


### MODIFY BELOW ###
class SpecialBlackjack:
    def __init__(self, cards: List[Card]) -> None:
        """
        FILL OUT DOCSTRING
        """
        self.cards = cards
        # No extra data members are allowed (but you might want to do work here)

    def num_ways_to_get_sum(self, target: int) -> int:
        """
        FILL OUT DOCSTRING
        """
        pass
